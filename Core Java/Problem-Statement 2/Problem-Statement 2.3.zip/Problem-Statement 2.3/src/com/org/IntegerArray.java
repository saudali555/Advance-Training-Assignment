package com.org;

import java.util.Arrays;

public class IntegerArray {

	public static void main(String[] args) {
		int[] arr = new int[] { 3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0 };
		int total = 0;
			int sum = 0;
		for (int i = 0; i < 14; i++) {
			sum = sum + arr[i];
		}
		arr[15] = sum;
		System.out.println("Sum of element from index 0 to 14, arr[15]= "+arr[15]);
		
		for (int i = 0; i < arr.length; i++) {
			total = total + arr[i];
		}
		
			//Average of all numbers
		for(int j=0; j<arr.length;j++) {
			total=total+arr[j];
		}
		
		int average = total / arr.length;
		arr[16] = (int) average;
		System.out.println("Average of all numbers, arr[16]= " +arr[16]);
		
		int min=arr[0];
		for(int x = 0; x < arr.length-1; x++){	   
			if(min > arr[x]){
				        min = arr[x];
				      }		   		   
				    }
		 System.out.println("Smallest Value of Array = " + min);				
		 arr[17]=min;	
		
		System.out.print("Array= ");
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
	}
}
